package Organisers;

import Miscellaneous.TimeStamper;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.TreeSet;

/*
 * This class arranges the activities into groups.
 */
/**
 *
 * @author Owner
 */
public class DDADS_Organiser implements Organiser {

    private TimeStamper timeStamper = new TimeStamper();
    //This code cannot be reused
    /*This method rearranges the activities, choose them according to their
    durations and time-stamps them*/
    @Override
    public List<String[]> organiseActivityGroups(List<String> activities) throws ParseException {

        shuffleItems(activities);
        List<String> selectedActivities = selectWithDuration(activities);
        List<String[]> stampedActivities = timeStamper.stampTime(selectedActivities);
        return stampedActivities;
    }

    //this code can be reused.
    /*This method shuffles the activities randomly so that there will be
    different combinations each time. Notice the use of type parameter T.
    This means this can sort any type of object e.g numbers, strings and even the
     ones of user defined type such as classes etc it can accept any reference type.
    This enables code reuse;
    
     */
    private <T> void shuffleItems(List<T> items) {
        final Random rgen = new Random();  // Random number generator			

        for (int i = 0; i < items.size(); i++) {
            final int randomPosition = rgen.nextInt(items.size());
            T temp = items.get(i);
            items.set(i, items.get(randomPosition));
            items.set(randomPosition, temp);
        }

    }

    /*this code is particularly tailored for Deloitte Digital Away Day task
    with the specified input and cannot be reused*/
 /*this method checks the times of the activities and selects them to
     to meet the 8 hour duration
     */
    private List<String> selectWithDuration(List<String> activities) {
        List<String> sortedActivities = new ArrayList<>();
        List<String> times = new ArrayList<>();
        List<String> timeSet = null;
        for (String line : activities) {
            int lineLength = line.split(" ").length;
            String time = line.split(" ")[lineLength - 1].split("min")[0];
            if (time.equals("sprint")) {
                times.add("15");
            } else {
                times.add(time);

            }

        }
        Collections.sort(times);
        timeSet = new ArrayList<>(new TreeSet<>(times));
        List<Integer> frequencies = new ArrayList<>();
        for (String t : timeSet) {
            int frequency = Collections.frequency(times, t);
            frequencies.add(frequency);

        }
        final Optional<Integer> max = frequencies.stream().max(Integer::compareTo);
        final Optional<Integer> min = frequencies.stream().min(Integer::compareTo);

        for (int i = 0; i < timeSet.size(); i++) {
            int counter = 0;
            for (int j = 0; j < activities.size(); j++) {
                int lineLength = activities.get(j).split(" ").length;
                String time = activities.get(j).split(" ")[lineLength - 1].split("min")[0];
                if (time.equals("sprint")) {
                    time = "15";
                }
                if (frequencies.get(i) > min.get()
                        && frequencies.get(i) < max.get()) {

                    if (time.equals(timeSet.get(i))) {
                        sortedActivities.add(activities.remove(j));
                        counter++;
                    }
                    if (counter == 2) {
                        break;
                    }
                }

                if (frequencies.get(i) == max.get().intValue()) {

                    if (time.equals(timeSet.get(i))) {
                        sortedActivities.add(activities.remove(j));
                        counter++;
                    }
                    if (counter == 4) {
                        break;
                    }
                }

            }
        }
        sortedActivities.addAll(activities);
        return sortedActivities;
    }
}
