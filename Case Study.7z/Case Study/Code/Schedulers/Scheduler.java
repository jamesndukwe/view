package Schedulers;

import Organisers.Organiser;
import Schedulers.Schedule;
import java.text.ParseException;
import java.util.List;

/*
 * This is an interface that enables any class that implements it to 
 * specify how how it want to create its schedule. This enables code
   flexibility
 */
/**
 *
 * @author Owner
 */
public interface Scheduler {
//an abstract method (contract) to be fulfilled by any class that wants to implement the scheduler

    List<Schedule> createSchedules(List<String> activities, Organiser organiser) throws ParseException;

}
