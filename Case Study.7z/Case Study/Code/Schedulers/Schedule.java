package Schedulers;

import Miscellaneous.Team;

/*
 * This is an interface to be implemented by any class that schedules 
  activities for DDADS.
 */
/**
 *
 * @author Owner
 */
public interface Schedule {

    /*This methods are to be implemented by the class wants to schedule 
    activities.*/
    //abstract method that adds activities to the schedule. 
    void addActivities(String[] activities);

    //abstract method that adds team to the schedule.
    void addTeam(Team team);

    //abstract method that retrieves activities from the schedule.
    String[] getActivities();

    //abstract method that retrieves team from the schedule.
    Team getTeam();

}
