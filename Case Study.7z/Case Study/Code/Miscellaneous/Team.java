package Miscellaneous;

/*
 * This is class that is used to create team objects
 */
/**
 *
 * @author Owner
 */
public class Team {

    private String teamName;

    //initialize Team object with its name
    public Team(String name) {
        teamName = name;
    }

    //retrieve name of the team
    public String getName() {
        return teamName;
    }

    //rename the team
    public void setName(String name) {
        teamName = name;
    }
}
