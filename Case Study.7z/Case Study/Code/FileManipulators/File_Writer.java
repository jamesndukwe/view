package FileManipulators;

import Schedulers.Schedule;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/*
 * This class writes data to text files in system default encoding. The T type
 parameter implements Schedule which allows class that uses File_Writer to use
any type argument that implements Schedule or extends DDADS_Schedule. This enables
code flexibility, reuse and maintenability. The Extension enables reusability and 
the implementation enables flexibility.
 */
/**
 *
 * @author Owner
 * @param <T>
 */
public class File_Writer<T extends Schedule> implements Writer<T> {

    //this code can be reused
    /*This method takes takes a schedule and extract the activities and
    teams from that schedule and then writes the information to a file.    
     */
    @Override
    public void writeFile(List<T> schedules) {

        // The name of the file to open.
        final String fileName = "schedule.txt";
        final int noOfSections = schedules.size();
        List<String> outputList = new ArrayList<>();

        for (int sectionNo = 0; sectionNo < noOfSections; sectionNo++) {
            outputList.add(schedules.get(sectionNo).getTeam().getName() + ":");
            String[] section = schedules.get(sectionNo).getActivities();
            outputList.addAll(Arrays.asList(section));
            if (sectionNo < 1) {
                outputList.add(" ");
            }
        }
        try {
            // Assume default encoding.
            FileWriter fileWriter
                    = new FileWriter(fileName);

            // Always wrap FileWriter in BufferedWriter.
            BufferedWriter bufferedWriter
                    = new BufferedWriter(fileWriter);

            // Note that write() does not automatically
            // append a newline character.
            for (String line : outputList) {
                bufferedWriter.write(line);
                bufferedWriter.newLine();
            }

            // Always close files.
            bufferedWriter.close();
        } catch (IOException ex) {
            System.out.println(
                    "Error writing to file '"
                    + fileName + "'");
            // Or we could just do this:
            // ex.printStackTrace();
        }
    }

}
