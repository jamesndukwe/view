package FileManipulators;

import java.util.List;

/*
 * This is an interface that any class that reads the file for DDADS
 must implement. This allows code flexibility as well as maintenance.
 */
/**
 *
 * @author Owner
 */
public interface Reader<T> {

    //method to be implemented by any class that reads  file
    List<T> readFile();

}
