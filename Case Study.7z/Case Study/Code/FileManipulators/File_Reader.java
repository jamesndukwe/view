package FileManipulators;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/*
 * This class reads text files in system default encoding. The T type parameter
allows the class to return the values as the specified type argument e.g 
File_Reader<String> will return the read value as string.
 */
/**
 *
 * @author Owner
 * @param <T>
 */
public class File_Reader<T> implements Reader<T> {

    //this code can be reused
    /*This method returns the read data as the specifiled type.
    assuming only integers were stored in the text file then in order to read
    and return the data as integer objects you have to instantiate File_Reader with
    the type argument 'Integer' and then call this method. This enables code reuse.
     */

    @Override
    public List<T> readFile() {

        // The name of the file to open.
        final String fileName = "activities.txt";

        // This will reference one line at a time
        T line = null;
        final List<T> activitiesAndTimes = new ArrayList<>();

        try {
            // FileReader reads text files in the default encoding.
            FileReader fileReader
                    = new FileReader(fileName);

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader
                    = new BufferedReader(fileReader);

            while ((line = (T) bufferedReader.readLine()) != null) {
                activitiesAndTimes.add(line);
            }

            // Always close files.
            bufferedReader.close();
        } catch (FileNotFoundException ex) {
            System.out.println(
                    "Unable to open file '"
                    + fileName + "'");
        } catch (IOException ex) {
            System.out.println(
                    "Error reading file '"
                    + fileName + "'");
            // Or we could just do this: 
            //ex.printStackTrace();
        }
        return activitiesAndTimes;
    }
}
